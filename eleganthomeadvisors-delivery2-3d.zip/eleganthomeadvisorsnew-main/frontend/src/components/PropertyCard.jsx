import React, { useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, Home, Ruler, CalendarClock, Star, MessageSquare, CalendarCheck } from "lucide-react";
import { SaveButton, CompareButton } from "@/components/PropertyActions";
import LeadDialog from "@/components/LeadDialog";
import { PLACEHOLDER_IMG, formatSqft, propertyCarpetArea } from "@/lib/media";

const badgeColors = {
    "New Launch": "bg-emerald-500 text-white",
    "Hot Deal": "bg-red-500 text-white",
    "Limited Inventory": "bg-amber-500 text-white",
    "Sold Out": "bg-slate-500 text-white",
};

export default function PropertyCard({ property, reasons = [] }) {
    const [dialog, setDialog] = useState(null);   // "enquiry" | "site_visit"
    const area = propertyCarpetArea(property);
    const place = [property.locality, property.location].filter(Boolean).join(", ");
    const detail = `/property/${property.slug}`;

    const facts = [
        { icon: Home, label: "Configuration", value: property.configuration },
        area ? { icon: Ruler, label: "Carpet area", value: formatSqft(area) } : null,
        { icon: CalendarClock, label: "Possession", value: property.possession || property.possession_status },
    ].filter((f) => f && f.value);

    return (
        <article className="card-elegant overflow-hidden group flex flex-col" data-testid={`property-card-${property.slug}`}>
            <div className="relative h-60 overflow-hidden">
                <Link to={detail} className="block h-full" aria-label={`View ${property.name}`}>
                    <img
                        src={property.cover_image || property.images?.[0] || PLACEHOLDER_IMG}
                        alt={`${property.name} in ${place}`}
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                        loading="lazy" decoding="async"
                        onError={(e) => { e.currentTarget.src = PLACEHOLDER_IMG; }}
                    />
                </Link>
                <div className="absolute top-4 left-4 flex gap-2 flex-wrap pointer-events-none">
                    {property.badge && (
                        <span className={`text-[10px] uppercase tracking-widest font-medium px-2.5 py-1 rounded-full ${badgeColors[property.badge] || "bg-slate-700 text-white"}`}>{property.badge}</span>
                    )}
                    {property.featured && (
                        <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest font-medium px-2.5 py-1 rounded-full bg-[var(--gold)] text-[var(--navy)]"><Star size={10} aria-hidden="true" /> Featured</span>
                    )}
                    <span className="text-[10px] uppercase tracking-widest font-medium px-2.5 py-1 rounded-full bg-white/90 text-[var(--navy)]">{property.category}</span>
                </div>
                <div className="absolute top-4 right-4 flex flex-col gap-2">
                    <SaveButton property={property} />
                    <CompareButton property={property} />
                </div>
            </div>

            <div className="p-5 flex flex-col flex-1">
                <div className="text-[11px] uppercase tracking-widest text-[var(--gold-dark)] font-medium">{property.builder}</div>
                <h3 className="font-serif-display text-2xl text-[var(--navy)] mt-1 leading-tight">
                    <Link to={detail} className="hover:text-[var(--gold-dark)] transition-colors duration-300">{property.name}</Link>
                </h3>
                <div className="mt-2 flex items-center gap-1.5 text-slate-600 text-sm"><MapPin size={14} className="text-[var(--gold)]" aria-hidden="true" /> {place}</div>

                {facts.length > 0 && (
                    <dl className="mt-4 grid grid-cols-1 gap-1.5 text-sm">
                        {facts.map(({ icon: Icon, label, value }) => (
                            <div key={label} className="flex items-center gap-2 text-slate-600">
                                <Icon size={14} className="text-[var(--gold)] shrink-0" aria-hidden="true" />
                                <dt className="sr-only">{label}</dt>
                                <dd className="truncate">{value}</dd>
                            </div>
                        ))}
                    </dl>
                )}

                {reasons.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-1.5" aria-label="Why this is similar">
                        {reasons.map((r) => <span key={r} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{r}</span>)}
                    </div>
                )}

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-end justify-between">
                    <div>
                        <div className="text-[10px] uppercase tracking-widest text-slate-500">Starting from</div>
                        <div className="font-serif-display text-xl text-[var(--navy)]">{property.starting_price}</div>
                    </div>
                    <Link to={detail} className="text-[13px] font-medium text-[var(--navy)] gold-underline" data-testid={`view-details-${property.slug}`}>View Details →</Link>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setDialog("site_visit")} className="flex items-center justify-center gap-1.5 text-[12px] py-2.5 rounded-full bg-[var(--gold)] text-[var(--navy)] font-medium" data-testid={`visit-${property.slug}`}>
                        <CalendarCheck size={14} /> Schedule visit
                    </button>
                    <button type="button" onClick={() => setDialog("enquiry")} className="flex items-center justify-center gap-1.5 text-[12px] py-2.5 rounded-full bg-[var(--navy)] text-white" data-testid={`enquire-${property.slug}`}>
                        <MessageSquare size={14} /> Enquire
                    </button>
                </div>
            </div>
            {dialog && <LeadDialog mode={dialog} open onOpenChange={(o) => !o && setDialog(null)} property={property} source="property_card"
                defaultMessage={dialog === "enquiry" ? `Hi, I am interested in ${property.name}. Please share pricing and availability.` : ""} />}
        </article>
    );
}
